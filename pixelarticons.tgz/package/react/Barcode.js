import React from 'react';
export const Barcode = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 4h2v16H2zm4 0h3v16H6zm5 0h3v16h-3zm5 0h2v16h-2zm4 0h2v16h-2z"}));
