import React from 'react';
export const EraserSolid = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M15 6h2v2h2v2h2v2h-2v2h-4v-2h-2v2h2v4h6v2H7v-2H5v-2H3v-2h2v-2h2v-2h4v2h2v-2h-2V6h2V4h2v2Z"}));
