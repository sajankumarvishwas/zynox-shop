import React from 'react';
export const AlignVerticalDistributeEndSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 18v-3h2v3zm-2 2v-2h20v2zm16-2v-3h2v3zM4 15v-2h16v2zm3-9v3h2V6zm0-2v2h10V4zm8 2v3h2V6zM2 9v2h20V9z"}));
