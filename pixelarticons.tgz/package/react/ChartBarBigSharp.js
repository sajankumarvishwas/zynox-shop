import React from 'react';
export const ChartBarBigSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 20h18v2H4zM2 2h2v20H2zm16 11v3h-2v-3zM8 13v3H6v-3zm10-2v2H6v-2zm0 5v2H6v-2zm2-12v3h-2V4zM8 4v3H6V4zm12-2v2H6V2zm0 5v2H6V7z"}));
