import React from 'react';
export const AlignHorizontalDistributeStartSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M6 4h3v2H6zM4 2h2v20H4zm2 16h3v2H6zM9 4h2v16H9zm9 3h-3v2h3zm2 0h-2v10h2zm-2 8h-3v2h3zM15 2h-2v20h2z"}));
