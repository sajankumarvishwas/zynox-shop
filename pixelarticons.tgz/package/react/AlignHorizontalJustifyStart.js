import React from 'react';
export const AlignHorizontalJustifyStart = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 2v20H2V2zm4 2h3v2H8zM6 6h2v12H6zm2 12h3v2H8zm3-12h2v12h-2zm6 1h3v2h-3zm-2 2h2v6h-2zm2 6h3v2h-3zm3-6h2v6h-2z"}));
