import React from 'react';
export const AirplaySharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 3h20v2H2zm0 2h2v12H2zm18 0h2v12h-2zM2 17h4v2H2zm16 0h4v2h-4zm-7-2h2v2h-2zm-2 2h4v2H9zm4 0h2v2h-2zm2 2h2v2h-2zm-8 0h8v2H7z"}));
