import React from 'react';
export const AlignVerticalSpaceBetweenSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 19v-3h2v3zm-2 2v-2h20v2zm16-2v-3h2v3zM4 16v-2h16v2zm3-8V5h2v3zm0 2V8h10v2zm8-2V5h2v3zM2 5V3h20v2z"}));
