import React from 'react';
export const CompassSolid = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M18 4H20V6H22V18H20V20H18V22H6V20H4V18H2V6H4V4H6V2H18V4ZM14 6H12V8H10V10H8V19H10V18H12V16H14V14H16V5H14V6ZM13 13H11V11H13V13Z"}));
