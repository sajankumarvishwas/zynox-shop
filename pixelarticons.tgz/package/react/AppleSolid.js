import React from 'react';
export const AppleSolid = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M11 8h3V6h4v2h2v3h-2v4h2v5h-2v2h-4v-2h-3v2H7v-2H5v-2H3v-8h2V8h2V6h4v2Zm3-3h-2V3h2v2Zm2-2h-2V1h2v2Z"}));
