import React from 'react';
export const DollarSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M19 18h-6v4h-2v-4H5v-2h12v-3H5V6h6V2h2v4h6v2H7v3h12v7Z"}));
