import React from 'react';
export const GitlabSolid = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M7 4h2v4h6V4h2V2h2v2h2v4h2v6h-2v2h-2v2h-2v2h-2v2H9v-2H7v-2H5v-2H3v-2H1V8h2V4h2V2h2v2Z"}));
