import React from 'react';
export const AlignEndVerticalSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 5v4h2V5zm0-2v2h16V3zm14 2v4h2V5zM2 9v2h16V9zm7 6v4h2v-4zm0-2v2h9v-2zm7 2v4h2v-4zm-7 4v2h9v-2zM20 2v20h2V2z"}));
