import React from 'react';
export const Google = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M17 21H7v-2h10v2ZM7 19H5v-2h2v2Zm12 0h-2v-2h2v2ZM5 17H3V7h2v10Zm16 0h-2v-4h-6v-2h8v6ZM7 7H5V5h2v2Zm12 0h-2V5h2v2Zm-2-2H7V3h10v2Z"}));
