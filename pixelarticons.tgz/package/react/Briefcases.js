import React from 'react';
export const Briefcases = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M6 8h2v8H6zm14 0h2v8h-2zM8 6h12v2H8zm0 10h12v2H8zm-6-4h2v8H2zm2 8h12v2H4zm6-16h2v2h-2zm2-2h4v2h-4zm4 2h2v2h-2zM4 10h2v2H4zm12 8h2v2h-2z"}));
