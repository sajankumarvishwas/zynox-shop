import React from 'react';
export const CornerUpLeftSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M18 8H4v2h14zm2 0h-2v12h2zM8 14h2v-2H8zm-2-2h2v-2H6zm0-4h2V6H6z"}), React.createElement('path', {d: "M8 12h2V4H8z"}));
