import React from 'react';
export const ArrowRightBox = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 2h16v2H4zm0 18h16v2H4zM2 4h2v16H2zm18 0h2v16h-2zm-3.933 7.009v2h2v-2zm-10 0v2h6v-2zm8-2v6h2v-6zm-2-2v10h2v-10z"}));
