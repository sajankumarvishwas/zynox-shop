import React from 'react';
export const ArrowDownNarrowWide = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M6 3h2v18H6z"}), React.createElement('path', {d: "M4 17h6v2H4zm-2-2h10v2H2zm8-12h6v2h-6zm0 4h9v2h-9zm0 4h12v2H10z"}));
