import React from 'react';
export const AlignVerticalDistributeStart = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 6v3h2V6zM2 4v2h20V4zm16 2v3h2V6zM6 9v2h12V9zm1 9v-3h2v3zm2 2v-2h6v2zm6-2v-3h2v3zM2 15v-2h20v2z"}));
