import React from 'react';
export const AlignHorizontalJustifyEndSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M20 2v20h2V2zM7 4H4v2h3zm2 0H7v16h2zM7 18H4v2h3zM4 4H2v16h2zm9 3h3v2h-3zm-2 0h2v10h-2zm2 8h3v2h-3zm3-8h2v10h-2z"}));
