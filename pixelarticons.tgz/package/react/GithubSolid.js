import React from 'react';
export const GithubSolid = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M19 14h-2v2h-2v2h2v4H7v-4H3v-2H1v-2h2v2h4v-2H5v-2H3V6h2V2h4v2h6V2h4v4h2v6h-2v2ZM7 18h2v-2H7v2Z"}));
