import React from 'react';
export const CornerLeftDown = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M8 6v14h2V6zm2-2v2h10V4zm4 12v-2h-2v2zm-2 2v-2h-2v2zm-4 0v-2H6v2z"}), React.createElement('path', {d: "M14 16v-2H4v2z"}));
