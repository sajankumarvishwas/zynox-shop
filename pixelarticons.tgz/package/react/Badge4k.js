import React from 'react';
export const Badge4k = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M3 4h18v2H3zm0 14h18v2H3zM1 6h2v12H1zm20 0h2v12h-2zM5 8h2v5H5zm4 0h2v8H9zm4 0h2v8h-2zm4 0h2v3h-2zm0 5h2v3h-2zm-2-2h2v2h-2zm-8 0h2v2H7z"}));
