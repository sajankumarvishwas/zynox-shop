import React from 'react';
export const AlignStartHorizontal = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M5 22h4v-2H5zm-2-2h2V8H3zM5 8h4V6H5zm4 12h2V8H9zm6-5h4v-2h-4zm-2-2h2V8h-2zm2-5h4V6h-4zm4 5h2V8h-2zM2 4h20V2H2z"}));
