import React from 'react';
export const ChevronsVertical2 = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M15 16v2h-2v2h-2v-2H9v-2H7v-2h10v2h-2ZM9 8V6h2V4h2v2h2v2h2v2H7V8h2Z"}));
