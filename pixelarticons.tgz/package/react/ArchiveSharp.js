import React from 'react';
export const ArchiveSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M1 2h22v2H1zm0 5h22v2H1zm0-3h2v3H1zm20 0h2v3h-2zm-2 5h2v11h-2zM3 9h2v11H3zm0 11h18v2H3zm6-9h6v2H9z"}));
