import React from 'react';
export const CornerUpRightSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M6 8h14v2H6zM4 8h2v12H4zm12 6h-2v-2h2zm2-2h-2v-2h2zm0-4h-2V6h2z"}), React.createElement('path', {d: "M16 12h-2V4h2z"}));
