import React from 'react';
export const Cross = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M14 22h-4v-2h4v2Zm-4-2H8v-4H4v-2h6v6Zm10-4h-4v4h-2v-6h6v2ZM4 14H2v-4h2v4Zm18 0h-2v-4h2v4Zm-12-4H4V8h4V4h2v6Zm6-2h4v2h-6V4h2v4Zm-2-4h-4V2h4v2Z"}));
