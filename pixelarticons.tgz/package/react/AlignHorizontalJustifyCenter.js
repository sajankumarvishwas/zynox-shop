import React from 'react';
export const AlignHorizontalJustifyCenter = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M11 2v20h2V2zM7 4H4v2h3zm2 2H7v12h2zM7 18H4v2h3zM4 6H2v12h2zm13 1h3v2h-3zm-2 2h2v6h-2zm2 6h3v2h-3zm3-6h2v6h-2z"}));
