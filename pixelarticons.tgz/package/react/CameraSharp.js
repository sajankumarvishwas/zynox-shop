import React from 'react';
export const CameraSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 5h6v2H2zm4-2h12v2H6zm10 2h6v2h-6zM2 7h2v12H2zm0 12h20v2H2zM20 7h2v12h-2zM10 8h4v2h-4zm0 6h4v2h-4zm-2-4h2v4H8zm6 0h2v4h-2z"}));
