import React from 'react';
export const ChevronsHorizontal2 = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M8 15H6v-2H4v-2h2V9h2V7h2v10H8v-2Zm8-6h2v2h2v2h-2v2h-2v2h-2V7h2v2Z"}));
