import React from 'react';
export const AlignVerticalSpaceAround = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M18 10v4h-2v-4zm-2-2v2H8V8zm-8 2v4H6v-4zm8 4v2H8v-2zm6-10H2v2h20zm0 14H2v2h20z"}));
