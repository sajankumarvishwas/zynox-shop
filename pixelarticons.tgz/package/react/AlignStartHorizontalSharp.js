import React from 'react';
export const AlignStartHorizontalSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M5 22h4v-2H5zm-2 0h2V6H3zM5 8h4V6H5zm4 14h2V6H9zm6-7h4v-2h-4zm-2 0h2V6h-2zm2-7h4V6h-4zm4 7h2V6h-2zM2 4h20V2H2z"}));
