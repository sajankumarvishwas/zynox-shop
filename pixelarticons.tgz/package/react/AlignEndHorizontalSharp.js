import React from 'react';
export const AlignEndHorizontalSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M3 2h8v2H3zm0 2h2v12H3zm0 12h8v2H3zM9 4h2v12H9zm4 5h8v2h-8zm0 2h2v5h-2zm0 5h8v2h-8zm6-5h2v5h-2zM2 20h20v2H2z"}));
