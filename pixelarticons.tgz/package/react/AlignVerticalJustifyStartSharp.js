import React from 'react';
export const AlignVerticalJustifyStartSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 4h20V2H2zm5 4v3h2V8zm0-2v2h10V6zm8 2v3h2V8zm-8 3v2h10v-2zm-3 6v3h2v-3zm0-2v2h16v-2zm14 2v3h2v-3zM4 20v2h16v-2z"}));
