import React from 'react';
export const BriefcaseSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 8h2v12H2zm18 0h2v12h-2zM2 6h20v2H2zm0 14h20v2H2zM8 4h2v2H8zm0-2h8v2H8zm6 2h2v2h-2z"}));
