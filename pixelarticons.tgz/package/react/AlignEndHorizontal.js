import React from 'react';
export const AlignEndHorizontal = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M5 2h4v2H5zM3 4h2v12H3zm2 12h4v2H5zM9 4h2v12H9zm6 5h4v2h-4zm-2 2h2v5h-2zm2 5h4v2h-4zm4-5h2v5h-2zM2 20h20v2H2z"}));
