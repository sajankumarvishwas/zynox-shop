import React from 'react';
export const Gmail = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M20 20H4v-2h16v2ZM4 18H2V6h2v12Zm18 0h-2V6h2v12ZM8 10h2v2H8v4H6V8h2v2Zm10 6h-2v-4h-2v-2h2V8h2v8Zm-4-2h-4v-2h4v2Zm6-8H4V4h16v2Z"}));
