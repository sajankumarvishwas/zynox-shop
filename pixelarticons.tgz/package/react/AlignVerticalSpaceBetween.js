import React from 'react';
export const AlignVerticalSpaceBetween = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 19v-3h2v3zm-2 2v-2h20v2zm16-2v-3h2v3zM6 16v-2h12v2zm1-8V5h2v3zm2 2V8h6v2zm6-2V5h2v3zM2 5V3h20v2z"}));
