import React from 'react';
export const ArrowLeftBoxSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 2h20v2H2zm0 18h20v2H2zM2 4h2v16H2zm18 0h2v16h-2zM8.067 11.009v2h-2v-2zm10 0v2h-6v-2zm-8-2v6h-2v-6zm2-2v10h-2v-10z"}));
