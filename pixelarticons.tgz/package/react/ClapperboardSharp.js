import React from 'react';
export const ClapperboardSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 3h20v2H2zm2 6h16v2H4zM2 5h2v14H2zm18 0h2v14h-2zM2 19h20v2H2zM18 7h-2v2h2zm-8 0H8v2h2zm6-2h-2v2h2zM8 5H6v2h2z"}));
