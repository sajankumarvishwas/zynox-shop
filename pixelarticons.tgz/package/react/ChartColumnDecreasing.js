import React from 'react';
export const ChartColumnDecreasing = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 20h18v2H4zM2 2h2v18H2zm5 4h2v12H7zm5 4h2v8h-2zm5 4h2v4h-2z"}));
