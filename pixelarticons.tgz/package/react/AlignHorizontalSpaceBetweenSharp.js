import React from 'react';
export const AlignHorizontalSpaceBetweenSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M5 4h3v2H5zM3 2h2v20H3zm2 16h3v2H5zM8 4h2v16H8zm8 3h3v2h-3zm-2 0h2v10h-2zm2 8h3v2h-3zm3-13h2v20h-2z"}));
