import React from 'react';
export const CoffeeSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M4 4h16v2H4zm0 2h2v8H4zm0 8h14v2H4zM20 4h2v8h-2zm-2 6h2v2h-2zm-2-4h2v8h-2zM2 18h18v2H2z"}));
