import React from 'react';
export const HandbagSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M7 4h2v7H7zm2-2h6v2H9zm6 2h2v7h-2z"}), React.createElement('path', {d: "M1 7h22v2H1zm20 2h2v11h-2zM3 9H1v11h2zM1 20h22v2H1z"}));
