import React from 'react';
export const BanknoteSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M1 5h22v2H1zm0 2h2v10H1zm0 10h22v2H1zM21 7h2v10h-2zM9 9h6v2H9zm0 2h2v2H9zm0 2h6v2H9zm4-2h2v2h-2zm4 0h2v2h-2zM5 11h2v2H5z"}));
