import React from 'react';
export const FloatRightSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 6h10v2H2zm0 4h10v2H2zm0 4h20v2H2zm0 4h20v2H2zM14 4h8v2h-8zm0 6h8v2h-8zm0-4h2v4h-2zm6 0h2v4h-2z"}));
