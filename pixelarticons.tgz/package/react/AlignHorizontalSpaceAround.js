import React from 'react';
export const AlignHorizontalSpaceAround = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M10 6h4v2h-4zM8 8h2v8H8zm2 8h4v2h-4zm4-8h2v8h-2zM4 2v20h2V2zm14 0v20h2V2z"}));
