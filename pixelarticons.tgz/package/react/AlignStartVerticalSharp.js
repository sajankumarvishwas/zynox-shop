import React from 'react';
export const AlignStartVerticalSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M22 5v4h-2V5zm0-2v2H6V3zM8 5v4H6V5zm14 4v2H6V9zm-7 6v4h-2v-4zm0-2v2H6v-2zm-7 2v4H6v-4zm7 4v2H6v-2zM4 2v20H2V2z"}));
