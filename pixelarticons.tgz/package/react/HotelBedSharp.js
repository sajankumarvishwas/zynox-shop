import React from 'react';
export const HotelBedSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 16h10V8h12v12h-2v-2H2v2H0V4h2v12Zm12 0h8v-6h-8v6Zm-5-1H5v-2h4v2Zm-4-2H3V9h2v4Zm6 0H9V9h2v4ZM9 9H5V7h4v2Z"}));
