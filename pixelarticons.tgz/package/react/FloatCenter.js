import React from 'react';
export const FloatCenter = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M18 6h4v2h-4zm0 4h4v2h-4zM2 6h4v2H2zm0 4h4v2H2zm0 4h20v2H2zm0 4h20v2H2zm8-14h4v2h-4zm0 6h4v2h-4zM8 6h2v4H8zm6 0h2v4h-2z"}));
