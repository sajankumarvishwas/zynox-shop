import React from 'react';
export const CornerRightUpSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M16 20V4h-2v16zm-2 0v-2H4v2z"}), React.createElement('path', {d: "M10 8v2h8V8zm2-2v2h2V6zm4 0v2h2V6zm2 2v2h2V8z"}));
