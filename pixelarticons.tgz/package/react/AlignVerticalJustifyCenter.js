import React from 'react';
export const AlignVerticalJustifyCenter = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M2 13h20v-2H2zm2 4v3h2v-3zm2-2v2h12v-2zm12 2v3h2v-3zM6 20v2h12v-2zM7 7V4h2v3zm2 2V7h6v2zm6-2V4h2v3zM9 4V2h6v2z"}));
