import React from 'react';
export const AtSignSharp = (props) => React.createElement('svg', Object.assign({viewBox: '0 0 24 24', width: '24', height: '24', fill: 'currentColor', xmlns: 'http://www.w3.org/2000/svg'}, props), React.createElement('path', {d: "M9 8h6v2H9zm0 6h8v2H9zm-2 2V8h2v8z"}), React.createElement('path', {d: "M13 14V8h2v6zm4-10h2v12h-2zM3 4h14v2H3zm0 2h2v12H3zm0 12h16v2H3z"}));
